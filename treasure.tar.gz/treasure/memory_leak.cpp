#include "headers.hpp"
#include "memory_leak.hpp"

boost::atomic<int> new_cnt(0);
